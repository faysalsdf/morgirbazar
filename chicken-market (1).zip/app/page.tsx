"use client"

import { useState, useEffect } from "react"
import { ShoppingCart, Plus, Minus, Star, Phone, MapPin, Clock, LogOut, LogIn } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Separator } from "@/components/ui/separator"
import { AuthModal } from "@/components/auth-modal"
import { CheckoutForm } from "@/components/checkout-form"

interface ChickenProduct {
  id: number
  name: string
  nameEn: string
  price: number
  originalPrice?: number
  discount?: number
  image: string
  description: string
  weight: string
  rating: number
  inStock: boolean
}

interface CartItem extends ChickenProduct {
  quantity: number
}

interface UserData {
  id: number
  name: string
  phone: string
  email: string
}

const chickenProducts: ChickenProduct[] = [
  {
    id: 1,
    name: "দেশি মুরগি",
    nameEn: "Deshi Chicken",
    price: 405,
    originalPrice: 450,
    discount: 10,
    image: "/placeholder.svg?height=200&width=200",
    description: "সম্পূর্ণ প্রাকৃতিক উপায়ে পালিত দেশি মুরগি। স্বাস্থ্যকর এবং সুস্বাদু।",
    weight: "1.2-1.5 কেজি",
    rating: 4.8,
    inStock: true,
  },
  {
    id: 2,
    name: "ব্রয়লার মুরগি",
    nameEn: "Broiler Chicken",
    price: 252,
    originalPrice: 280,
    discount: 10,
    image: "/placeholder.svg?height=200&width=200",
    description: "তাজা ব্রয়লার মুরগি। দ্রুত রান্নার জন্য উপযুক্ত।",
    weight: "1.5-2.0 কেজি",
    rating: 4.5,
    inStock: true,
  },
  {
    id: 3,
    name: "কক মুরগি",
    nameEn: "Cock Chicken",
    price: 468,
    originalPrice: 520,
    discount: 10,
    image: "/placeholder.svg?height=200&width=200",
    description: "বড় সাইজের কক মুরগি। বিশেষ অনুষ্ঠানের জন্য আদর্শ।",
    weight: "2.0-2.5 কেজি",
    rating: 4.7,
    inStock: true,
  },
  {
    id: 4,
    name: "মুরগির বাচ্চা",
    nameEn: "Young Chicken",
    price: 162,
    originalPrice: 180,
    discount: 10,
    image: "/placeholder.svg?height=200&width=200",
    description: "কোমল মুরগির বাচ্চা। দ্রুত রান্নার জন্য পারফেক্ট।",
    weight: "0.8-1.0 কেজি",
    rating: 4.6,
    inStock: true,
  },
  {
    id: 5,
    name: "কাটা মুরগি",
    nameEn: "Cut Chicken",
    price: 320,
    image: "/placeholder.svg?height=200&width=200",
    description: "পরিষ্কার করে কাটা মুরগি। রান্নার জন্য সম্পূর্ণ প্রস্তুত।",
    weight: "1.0 কেজি",
    rating: 4.4,
    inStock: false,
  },
  {
    id: 6,
    name: "অর্গানিক মুরগি",
    nameEn: "Organic Chicken",
    price: 585,
    originalPrice: 650,
    discount: 10,
    image: "/placeholder.svg?height=200&width=200",
    description: "সম্পূর্ণ অর্গানিক পদ্ধতিতে পালিত মুরগি। কোন রাসায়নিক ব্যবহার নেই।",
    weight: "1.3-1.8 কেজি",
    rating: 4.9,
    inStock: true,
  },
]

export default function ChickenMarket() {
  const [cart, setCart] = useState<CartItem[]>([])
  const [isCheckout, setIsCheckout] = useState(false)
  const [userData, setUserData] = useState<UserData | null>(null)
  const [showAuth, setShowAuth] = useState(false)
  const [isLogin, setIsLogin] = useState(true)

  // Load user from localStorage on component mount
  useEffect(() => {
    const savedUser = localStorage.getItem("chickenMarketUser")
    if (savedUser) {
      setUserData(JSON.parse(savedUser))
    }
  }, [])

  const handleLogin = (userData: UserData) => {
    setUserData(userData)
    localStorage.setItem("chickenMarketUser", JSON.stringify(userData))
    setShowAuth(false)
  }

  const handleLogout = () => {
    setUserData(null)
    localStorage.removeItem("chickenMarketUser")
    setCart([])
  }

  const addToCart = (product: ChickenProduct) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id)
      if (existing) {
        return prev.map((item) => (item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item))
      }
      return [...prev, { ...product, quantity: 1 }]
    })
  }

  const updateQuantity = (id: number, change: number) => {
    setCart((prev) => {
      return prev
        .map((item) => {
          if (item.id === id) {
            const newQuantity = item.quantity + change
            return newQuantity > 0 ? { ...item, quantity: newQuantity } : item
          }
          return item
        })
        .filter((item) => item.quantity > 0)
    })
  }

  const removeFromCart = (id: number) => {
    setCart((prev) => prev.filter((item) => item.id !== id))
  }

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="text-2xl font-bold text-green-600">🐔</div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">মুরগির বাজার</h1>
                <p className="text-sm text-gray-500">Chicken Market</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="hidden md:flex items-center space-x-4 text-sm text-gray-600">
                <div className="flex items-center space-x-1">
                  <Phone className="h-4 w-4" />
                  <span>০১৭১২-৩৪৫৬১২</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock className="h-4 w-4" />
                  <span>সকাল ৮টা - রাত ১০টা</span>
                </div>
              </div>

              {userData ? (
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-600">স্বাগতম, {userData.name}</span>
                  <Button variant="ghost" size="sm" onClick={handleLogout}>
                    <LogOut className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <Button variant="ghost" size="sm" onClick={() => setShowAuth(true)}>
                  <LogIn className="h-4 w-4 mr-1" />
                  লগইন
                </Button>
              )}

              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" size="sm" className="relative bg-transparent">
                    <ShoppingCart className="h-4 w-4" />
                    {getTotalItems() > 0 && (
                      <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                        {getTotalItems()}
                      </Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent className="w-full sm:max-w-lg">
                  <SheetHeader>
                    <SheetTitle>শপিং কার্ট ({getTotalItems()} টি পণ্য)</SheetTitle>
                  </SheetHeader>

                  {!isCheckout ? (
                    <div className="mt-6">
                      {cart.length === 0 ? (
                        <p className="text-center text-gray-500 py-8">আপনার কার্ট খালি</p>
                      ) : (
                        <>
                          <div className="space-y-4">
                            {cart.map((item) => (
                              <div key={item.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                                <img
                                  src={item.image || "/placeholder.svg"}
                                  alt={item.name}
                                  className="h-16 w-16 object-cover rounded"
                                />
                                <div className="flex-1">
                                  <h3 className="font-medium">{item.name}</h3>
                                  <p className="text-sm text-gray-500">{item.weight}</p>
                                  <p className="font-semibold text-green-600">৳{item.price}</p>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <Button size="sm" variant="outline" onClick={() => updateQuantity(item.id, -1)}>
                                    <Minus className="h-3 w-3" />
                                  </Button>
                                  <span className="w-8 text-center">{item.quantity}</span>
                                  <Button size="sm" variant="outline" onClick={() => updateQuantity(item.id, 1)}>
                                    <Plus className="h-3 w-3" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>

                          <Separator className="my-4" />

                          <div className="space-y-2">
                            <div className="flex justify-between text-lg font-semibold">
                              <span>মোট:</span>
                              <span className="text-green-600">৳{getTotalPrice()}</span>
                            </div>
                            <Button
                              className="w-full"
                              onClick={() => (userData ? setIsCheckout(true) : setShowAuth(true))}
                              disabled={cart.length === 0}
                            >
                              {userData ? "চেকআউট করুন" : "লগইন করুন"}
                            </Button>
                          </div>
                        </>
                      )}
                    </div>
                  ) : (
                    <CheckoutForm
                      cart={cart}
                      total={getTotalPrice()}
                      user={userData!}
                      onBack={() => setIsCheckout(false)}
                      onSuccess={() => {
                        setCart([])
                        setIsCheckout(false)
                      }}
                    />
                  )}
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-600 to-green-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">তাজা ও স্বাস্থ্যকর মুরগি</h2>
          <p className="text-xl mb-8">সরাসরি খামার থেকে আপনার ঘরে</p>
          <div className="flex justify-center items-center space-x-8 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-white rounded-full"></div>
              <span>১০০% হালাল</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-white rounded-full"></div>
              <span>তাজা ও পরিষ্কার</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-white rounded-full"></div>
              <span>ঘরে ডেলিভারি</span>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">আমাদের পণ্যসমূহ</h2>
            <p className="text-gray-600">বিভিন্ন ধরনের তাজা মুরগি পাবেন এখানে</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {chickenProducts.map((product) => (
              <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-48 object-cover"
                  />
                  {!product.inStock && (
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                      <Badge variant="destructive">স্টক নেই</Badge>
                    </div>
                  )}
                </div>

                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{product.name}</CardTitle>
                      <CardDescription className="text-sm text-gray-500">{product.nameEn}</CardDescription>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm">{product.rating}</span>
                    </div>
                  </div>
                </CardHeader>

                <CardContent>
                  <p className="text-sm text-gray-600 mb-3">{product.description}</p>
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      {product.discount ? (
                        <div>
                          <div className="flex items-center space-x-2">
                            <p className="text-lg font-bold text-green-600">৳{product.price}</p>
                            <p className="text-sm text-gray-500 line-through">৳{product.originalPrice}</p>
                            <Badge variant="destructive" className="text-xs">
                              {product.discount}% ছাড়
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-500">প্রতি কেজি</p>
                        </div>
                      ) : (
                        <div>
                          <p className="text-lg font-bold text-green-600">৳{product.price}</p>
                          <p className="text-sm text-gray-500">প্রতি কেজি</p>
                        </div>
                      )}
                    </div>
                    <Badge variant="outline">{product.weight}</Badge>
                  </div>

                  <Button
                    className="w-full"
                    onClick={() => (userData ? addToCart(product) : setShowAuth(true))}
                    disabled={!product.inStock}
                  >
                    {product.inStock ? "কার্টে যোগ করুন" : "স্টক নেই"}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">কেন আমাদের বেছে নিবেন?</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🚚</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">ফ্রি ডেলিভারি</h3>
              <p className="text-gray-600">৫০০ টাকার উপরে অর্ডারে ফ্রি ডেলিভারি</p>
            </div>

            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">✅</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">১০০% হালাল</h3>
              <p className="text-gray-600">ইসলামিক নিয়ম অনুযায়ী জবাই করা</p>
            </div>

            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">⏰</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">দ্রুত ডেলিভারি</h3>
              <p className="text-gray-600">২৪ ঘন্টার মধ্যে ডেলিভারি</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <span className="text-2xl">🐔</span>
                <span className="text-xl font-bold">মুরগির বাজার</span>
              </div>
              <p className="text-gray-400">তাজা ও স্বাস্থ্যকর মুরগি সরবরাহকারী। আমরা গুণগত মানের নিশ্চয়তা দিয়ে থাকি।</p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">যোগাযোগ</h3>
              <div className="space-y-2 text-gray-400">
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span>০১৭১২-৩৪৫৬১২</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4" />
                  <span>ঢাকা, বাংলাদেশ</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4" />
                  <span>সকাল ৮টা - রাত ১০টা</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">পেমেন্ট মেথড</h3>
              <div className="flex space-x-4">
                <div className="bg-white text-black px-3 py-1 rounded text-sm">bKash</div>
                <div className="bg-white text-black px-3 py-1 rounded text-sm">Nagad</div>
                <div className="bg-white text-black px-3 py-1 rounded text-sm">Rocket</div>
              </div>
            </div>
          </div>

          <Separator className="my-8 bg-gray-700" />

          <div className="text-center text-gray-400">
            <p>&copy; ২০২৪ মুরগির বাজার। সকল অধিকার সংরক্ষিত।</p>
          </div>
        </div>
      </footer>
      {showAuth && (
        <AuthModal
          isLogin={isLogin}
          onToggle={() => setIsLogin(!isLogin)}
          onClose={() => setShowAuth(false)}
          onLogin={handleLogin}
        />
      )}
    </div>
  )
}
