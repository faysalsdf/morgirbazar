"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Copy } from "lucide-react"

interface CartItem {
  id: number
  name: string
  price: number
  quantity: number
  weight: string
}

interface User {
  id: number
  name: string
  phone: string
  email: string
}

interface CheckoutFormProps {
  cart: CartItem[]
  total: number
  user: User
  onBack: () => void
  onSuccess: () => void
}

export function CheckoutForm({ cart, total, user, onBack, onSuccess }: CheckoutFormProps) {
  const [paymentMethod, setPaymentMethod] = useState("bkash")
  const [isProcessing, setIsProcessing] = useState(false)
  const [showPaymentDetails, setShowPaymentDetails] = useState(false)
  const [paymentConfirmed, setPaymentConfirmed] = useState(false)
  const [transactionId, setTransactionId] = useState("")

  // Your payment numbers (replace with actual numbers)
  const paymentNumbers = {
    bkash: "01712-345612",
    nagad: "01712-345612",
    rocket: "01712-345612",
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (paymentMethod === "cod") {
      // Cash on delivery - direct order confirmation
      setIsProcessing(true)
      setTimeout(() => {
        setIsProcessing(false)
        alert("অর্ডার সফলভাবে সম্পন্ন হয়েছে! আমরা শীঘ্রই আপনার সাথে যোগাযোগ করব।")
        onSuccess()
      }, 2000)
    } else {
      // Digital payment - show payment details
      setShowPaymentDetails(true)
    }
  }

  const handlePaymentConfirmation = () => {
    if (!transactionId.trim()) {
      alert("ট্রানজেকশন আইডি প্রয়োজন!")
      return
    }

    setIsProcessing(true)
    // Simulate payment verification
    setTimeout(() => {
      setIsProcessing(false)
      setPaymentConfirmed(true)
      alert("পেমেন্ট সফল! অর্ডার কনফার্ম হয়েছে। আমরা শীঘ্রই ডেলিভারি করব।")
      onSuccess()
    }, 2000)
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    alert("নম্বর কপি হয়েছে!")
  }

  if (showPaymentDetails && !paymentConfirmed) {
    return (
      <div className="mt-6">
        <Button variant="ghost" onClick={() => setShowPaymentDetails(false)} className="mb-4">
          ← পেমেন্ট মেথড পরিবর্তন করুন
        </Button>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span
                className={`px-3 py-1 rounded text-white text-sm ${
                  paymentMethod === "bkash"
                    ? "bg-pink-500"
                    : paymentMethod === "nagad"
                      ? "bg-orange-500"
                      : "bg-purple-500"
                }`}
              >
                {paymentMethod === "bkash" ? "bKash" : paymentMethod === "nagad" ? "Nagad" : "Rocket"}
              </span>
              <span>পেমেন্ট করুন</span>
            </CardTitle>
            <CardDescription>নিচের নম্বরে ৳{total} টাকা পাঠান</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-4 rounded-lg mb-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">পেমেন্ট নম্বর:</p>
                  <p className="text-xl font-bold">{paymentNumbers[paymentMethod as keyof typeof paymentNumbers]}</p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(paymentNumbers[paymentMethod as keyof typeof paymentNumbers])}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <h4 className="font-semibold mb-2">পেমেন্ট করার নিয়ম:</h4>
              <ol className="text-sm space-y-1 list-decimal list-inside">
                <li>আপনার {paymentMethod === "bkash" ? "বিকাশ" : paymentMethod === "nagad" ? "নগদ" : "রকেট"} অ্যাপ খুলুন</li>
                <li>"Send Money" অপশনে ক্লিক করুন</li>
                <li>উপরের নম্বরটি লিখুন</li>
                <li>৳{total} টাকা পাঠান</li>
                <li>ট্রানজেকশন আইডি নিচে লিখুন</li>
              </ol>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="transactionId">ট্রানজেকশন আইডি *</Label>
                <Input
                  id="transactionId"
                  value={transactionId}
                  onChange={(e) => setTransactionId(e.target.value)}
                  placeholder="যেমন: 8G5A7X9B2M"
                  required
                />
                <p className="text-xs text-gray-500 mt-1">পেমেন্ট করার পর যে ট্রানজেকশন আইডি পাবেন সেটি লিখুন</p>
              </div>

              <Button
                onClick={handlePaymentConfirmation}
                className="w-full"
                disabled={isProcessing || !transactionId.trim()}
              >
                {isProcessing ? "যাচাই করা হচ্ছে..." : "পেমেন্ট কনফার্ম করুন"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="mt-6">
      <Button variant="ghost" onClick={onBack} className="mb-4">
        ← কার্টে ফিরে যান
      </Button>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <Label className="text-base font-semibold">ডেলিভারি তথ্য</Label>
          <div className="grid grid-cols-2 gap-4 mt-2">
            <div>
              <Label htmlFor="name">নাম</Label>
              <Input id="name" value={user.name} disabled />
            </div>
            <div>
              <Label htmlFor="phone">ফোন নম্বর</Label>
              <Input id="phone" value={user.phone} disabled />
            </div>
          </div>
          <div className="mt-4">
            <Label htmlFor="address">সম্পূর্ণ ঠিকানা *</Label>
            <Textarea id="address" required placeholder="আপনার সম্পূর্ণ ঠিকানা লিখুন" />
          </div>
        </div>

        <div>
          <Label className="text-base font-semibold">পেমেন্ট মেথড</Label>
          <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="mt-2">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="bkash" id="bkash" />
              <Label htmlFor="bkash" className="flex items-center space-x-2">
                <span className="bg-pink-500 text-white px-2 py-1 rounded text-xs">bKash</span>
                <span>বিকাশ</span>
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="nagad" id="nagad" />
              <Label htmlFor="nagad" className="flex items-center space-x-2">
                <span className="bg-orange-500 text-white px-2 py-1 rounded text-xs">Nagad</span>
                <span>নগদ</span>
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="rocket" id="rocket" />
              <Label htmlFor="rocket" className="flex items-center space-x-2">
                <span className="bg-purple-500 text-white px-2 py-1 rounded text-xs">Rocket</span>
                <span>রকেট</span>
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="cod" id="cod" />
              <Label htmlFor="cod">ক্যাশ অন ডেলিভারি</Label>
            </div>
          </RadioGroup>
        </div>

        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="font-semibold mb-2">অর্ডার সামারি</h3>
          {cart.map((item) => (
            <div key={item.id} className="flex justify-between text-sm mb-1">
              <span>
                {item.name} x {item.quantity}
              </span>
              <span>৳{item.price * item.quantity}</span>
            </div>
          ))}
          <Separator className="my-2" />
          <div className="flex justify-between font-semibold">
            <span>মোট:</span>
            <span className="text-green-600">৳{total}</span>
          </div>
        </div>

        <Button type="submit" className="w-full" disabled={isProcessing}>
          {isProcessing ? "প্রসেসিং..." : paymentMethod === "cod" ? "অর্ডার কনফার্ম করুন" : "পেমেন্ট করুন"}
        </Button>
      </form>
    </div>
  )
}
