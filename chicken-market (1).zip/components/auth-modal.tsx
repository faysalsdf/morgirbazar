"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { X } from "lucide-react"

interface User {
  id: number
  name: string
  phone: string
  email: string
}

interface AuthModalProps {
  isLogin: boolean
  onToggle: () => void
  onClose: () => void
  onLogin: (user: User) => void
}

export function AuthModal({ isLogin, onToggle, onClose, onLogin }: AuthModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    password: "",
  })
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      if (isLogin) {
        // Simulate login
        const user: User = {
          id: 1,
          name: formData.name || "ব্যবহারকারী",
          phone: formData.phone,
          email: formData.email,
        }
        onLogin(user)
      } else {
        // Simulate registration
        const user: User = {
          id: Date.now(),
          name: formData.name,
          phone: formData.phone,
          email: formData.email,
        }
        onLogin(user)
      }
      setIsLoading(false)
    }, 1000)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="relative">
          <Button variant="ghost" size="sm" className="absolute right-0 top-0" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
          <CardTitle>{isLogin ? "লগইন করুন" : "নতুন একাউন্ট তৈরি করুন"}</CardTitle>
          <CardDescription>{isLogin ? "আপনার একাউন্টে প্রবেশ করুন" : "মুরগির বাজারে নতুন একাউন্ট তৈরি করুন"}</CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <Label htmlFor="name">নাম *</Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required={!isLogin}
                  placeholder="আপনার নাম লিখুন"
                />
              </div>
            )}

            <div>
              <Label htmlFor="phone">ফোন নম্বর *</Label>
              <Input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleChange}
                required
                placeholder="০১৭xxxxxxxx"
              />
            </div>

            {!isLogin && (
              <div>
                <Label htmlFor="email">ইমেইল</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="your@email.com"
                />
              </div>
            )}

            <div>
              <Label htmlFor="password">পাসওয়ার্ড *</Label>
              <Input
                id="password"
                name="password"
                type="password"
                value={formData.password}
                onChange={handleChange}
                required
                placeholder="পাসওয়ার্ড লিখুন"
              />
            </div>

            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? "অপেক্ষা করুন..." : isLogin ? "লগইন করুন" : "একাউন্ট তৈরি করুন"}
            </Button>
          </form>

          <div className="mt-4 text-center">
            <Button variant="link" onClick={onToggle}>
              {isLogin ? "নতুন একাউন্ট তৈরি করুন" : "ইতিমধ্যে একাউন্ট আছে? লগইন করুন"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
